﻿namespace AutoCC_Main
{
	class Machine
	{
		public int count = 0;
		public int index = 0;

		// later, machine id, machine name, machine session ... will be used.
	}
}
