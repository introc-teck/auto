﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Text;

namespace AutoCC_Main
{
	class DataDispatcher
	{
		private static string m_db_connection = "server=172.16.33.254;Database=Dprinting;UID=sa;PWD=gpadmin2011)(*&";

		public const int STATUS_INSPECT_START = 1;
		public const int STATUS_INSPECT_FINISH = 2;

		public const int RESULT_NONE = 0;
		public const int RESULT_SUCCEEDED = 1;
		public const int RESULT_FAILED = -1;

		public DataDispatcher()
		{
		}

		public static int GetWorkList4(Machine machine, ref List<Work> work_list)
		{
			try
			{
				string[] param = new string[1];
				param[0] = "id=" + "auto" + (AppConfiguration.machine.index).ToString();
				string result1 = request("GetAutoWaitingOrder.php", param);

				Work work = new Work();

				JObject obj = JObject.Parse(result1);

				work.order_date = obj["data"]["order_num"].ToString().Substring(3, 6);
				work.OPISeq = obj["data"]["order_num"].ToString().Substring(11, 5);
				work.order_common_seqno = Convert.ToInt32(obj["data"]["order_common_seqno"]);
				work.order_num = obj["data"]["order_num"].ToString();
				//						work.order_detail_dvs_num = data_table.Rows[i][3].ToString();
				work.OPICustomerID = obj["data"]["member_seqno"].ToString();
				work.category_code = obj["data"]["ProductCode"].ToString();
				work.category_name = obj["data"]["ProductName"].ToString();
				work.item_count = Convert.ToInt32(obj["data"]["CaseCode"].ToString());

				double bleed_width = Convert.ToDouble(obj["data"]["PWidth"].ToString());
				double bleed_height = Convert.ToDouble(obj["data"]["PHeight"].ToString());
				work.bleed_size = new System.Drawing.SizeF((float)bleed_width, (float)bleed_height);

				double trim_width = Convert.ToDouble(obj["data"]["Width"].ToString());
				double trim_height = Convert.ToDouble(obj["data"]["Height"].ToString());
				work.trim_size = new System.Drawing.SizeF((float)trim_width, (float)trim_height);

				work.Platform = obj["data"]["oper_sys"].ToString();

				work.file_path = obj["data"]["FilePath"].ToString();
				//work.file_path = @"\\172.16.33.224\gpnas\ndrive" + work.file_path.Replace("/", @"\");
				work.DownloadFile();
				/*
				if (work.Platform == "0")
					work.file_path = obj["data"]["FilePath"].ToString() + obj["data"]["FileName"].ToString();
				//work.file_path = string.Format("{0}IBM\\{1}\\{2}", AppConfiguration.config["ordered_folder"], work.order_date, obj["data"]["DSFile"].ToString());
				else if (work.Platform == "1")
					work.file_path = string.Format("{0}MAC\\{1}\\{2}", AppConfiguration.config["ordered_folder"], work.order_date, obj["data"]["DSFile"].ToString());
				*/

				work.ColorCode = obj["data"]["Tmpt"].ToString();
				if (work.ColorCode.Equals("4") == true)
					work.side_count = 1;
				else
					work.side_count = 2;

				work.PaperCode = obj["data"]["PaperCode"].ToString();
				work.PaperQuantity = Convert.ToDouble(obj["data"]["QuantityValue"].ToString());

				//work.Standard = obj["data"]["Standard"].ToString();
				work.Standard = obj["data"]["SizeCode"].ToString() == "비규격" ? "1" : "0";

				if (work.category_code == "003002001" || work.category_code == "003003001" || work.Standard == "1")
					work.magenta_outline = true;
				else
					work.magenta_outline = false;

				if (work.category_code.StartsWith("004"))
				{
					if ((bleed_width == trim_width) && (bleed_height == trim_height))
						work.magenta_outline = false;
					else
						work.magenta_outline = true;
				}

				//당일판
				work.PeriodAM = "N";

				//work.ImpositionPosition = obj["data"]["Digit"].ToString();
				work.ImpositionPosition = "1";

				work.CustomerName = obj["data"]["UCom"].ToString();

				work.DeliveryCode = obj["data"]["Method"].ToString();

				work.ExtraTitle = "없음";
				//work.SizeCode = obj["data"]["SizeCode"].ToString();
				//work.SubTypeCode = obj["data"]["SCode"].ToString();


				if (work_list == null)
					work_list = new List<Work>();
				work_list.Add(work);

				return (work_list == null ? 0 : work_list.Count);
			}
			catch
			{
				return 0;
			}
		}

		public static int GetWorkList(Machine machine, ref List<Work> work_list)
		{


			 string query = @"SELECT TOP(" + "10" + @") * FROM pdfauto..TbDPAutoList WITH (NOLOCK)  
			                     WHERE Status = 'W' AND (OPISeq % " + AppConfiguration.machine.count.ToString() + @") = " + 
			(AppConfiguration.machine.index - 1).ToString() + @" AND OPIDate > CONVERT(nvarchar(8), GetDate()-15, 112)
			                     ORDER BY InTime asc, OPIDate";

			// string query = @"SELECT * FROM pdfauto..TbDPAutoList WITH (NOLOCK)  
			//             WHERE   (OPISeq % " + AppConfiguration.machine.count.ToString() + @") = " +
			//(AppConfiguration.machine.index - 1).ToString() + @" AND OPIDate = '20201006' 
			//             ORDER BY InTime asc, OPIDate";


			//string query = @"SELECT * FROM pdfauto..TbDPAutoList WITH (NOLOCK)  
			//                     WHERE     OPIDate = '20201007' and opiseq =0694
			//             ORDER BY InTime asc, OPIDate";
			//DP - 20201007 - 0694 - 20201

			Console.WriteLine(query);

            DataTable data_table = QueryExecute(query);
			if (data_table != null)
			{
				try
				{
					foreach (DataRow row in data_table.Rows)
					{
						Work work = new Work();

						work.order_date = row["OPIDate"].ToString();
						work.OPISeq = row["OPISeq"].ToString();
						work.order_common_seqno = Convert.ToInt32(work.OPISeq);
						//						work.order_num = data_table.Rows[i][2].ToString();
						//						work.order_detail_dvs_num = data_table.Rows[i][3].ToString();
						work.OPICustomerID = row["OPICustID"].ToString();
						work.category_code = row["CaCode"].ToString();
						work.category_name = work.GetCategoryName();
						work.item_count = Convert.ToInt32(row["Num"].ToString());

						double bleed_width = Convert.ToDouble(row["EditSizeW"].ToString());
						double bleed_height = Convert.ToDouble(row["EditSizeH"].ToString());
						work.bleed_size = new System.Drawing.SizeF((float)bleed_width, (float)bleed_height);

						double trim_width = Convert.ToDouble(row["CutSizeW"].ToString());
						double trim_height = Convert.ToDouble(row["CutSizeH"].ToString());
						work.trim_size = new System.Drawing.SizeF((float)trim_width, (float)trim_height);

						work.Platform = row["DataGubun"].ToString();

						if (work.Platform == "0")
							work.file_path = string.Format("{0}IBM\\{1}\\{2}", AppConfiguration.config["ordered_folder"], work.order_date, row["DSFile"].ToString());
						else if (work.Platform == "1")
							work.file_path = string.Format("{0}MAC\\{1}\\{2}", AppConfiguration.config["ordered_folder"], work.order_date, row["DSFile"].ToString());

						work.ColorCode = row["ColorCode"].ToString();
						if (work.ColorCode.Equals("4") == true)
							work.side_count = 1;
						else
							work.side_count = 2;

						work.PaperCode = row["P1Code"].ToString();
						work.PaperQuantity = Convert.ToDouble(row["Qty"].ToString());

						work.Standard = row["Standard"].ToString();

						if (work.category_code == "N13" || work.category_code == "N14" || work.Standard == "1")
							work.magenta_outline = true;
						else
							work.magenta_outline = false;

						String cate1 = work.category_code.Substring(0, 1);
						if (cate1 == "S")
						{
							if ((bleed_width == trim_width) && (bleed_height == trim_height))
								work.magenta_outline = false;
							else
								work.magenta_outline = true;
						}

						work.PeriodAM = row["IsNonstand"].ToString();

						work.ImpositionPosition = row["Digit"].ToString();

						work.CustomerName = row["CustName"].ToString();

						// 2019-12-26 생성된 파일명의 고객이름이 너무 길면 Mac  조판 프로그램인 MoaMoa 에러가 발생 해서 고객명 축사작업 추가
						if (work.CustomerName.Length > 15)
						{
							work.CustomerName = work.CustomerName.Replace(" ", "").Substring(0, 15);
						}
						else
						{
							work.CustomerName = work.CustomerName.Replace(" ", "");
						}



						work.DeliveryCode = row["DCode"].ToString();

						work.ExtraTitle = row["TempTitle"].ToString();
						work.ExtraTitle = work.ExtraTitle.Replace(" ", "");
						if (string.IsNullOrEmpty(work.ExtraTitle) == true)
							work.ExtraTitle = "없음";

						work.SizeCode = row["SizeCode"].ToString();
						work.SubTypeCode = row["SCode"].ToString();

						work.Coating = row["Coating"].ToString();


						if (work_list == null)
							work_list = new List<Work>();
						work_list.Add(work);

					}
				}
				catch
				{
					work_list = null;
				}
			}

			return (work_list == null ? 0 : work_list.Count);
		}


		public static int GetWorkList2(ref List<Work> work_list, string _num, string _date)
		{

			string query = @"SELECT TOP(" + "10" + @") * FROM pdfauto..TbDPAutoList WITH (NOLOCK)  
			                 WHERE OPISeq = " + _num + " and OPIDate = '" + _date + "'";




			Console.WriteLine(query);

			string log = string.Format("[DB] GetWorkList. query_string: {0}", query);
			//	Logger.Log(log);

			DataTable data_table = QueryExecute(query);
			if (data_table != null)
			{
				try
				{
					foreach (DataRow row in data_table.Rows)
					{
						Work work = new Work();

						work.order_date = row["OPIDate"].ToString();
						work.OPISeq = row["OPISeq"].ToString();
						work.order_common_seqno = Convert.ToInt32(work.OPISeq);
						//						work.order_num = data_table.Rows[i][2].ToString();
						//						work.order_detail_dvs_num = data_table.Rows[i][3].ToString();
						work.OPICustomerID = row["OPICustID"].ToString();
						work.category_code = row["CaCode"].ToString();
						work.category_name = work.GetCategoryName();
						work.item_count = Convert.ToInt32(row["Num"].ToString());

						double bleed_width = Convert.ToDouble(row["EditSizeW"].ToString());
						double bleed_height = Convert.ToDouble(row["EditSizeH"].ToString());
						work.bleed_size = new System.Drawing.SizeF((float)bleed_width, (float)bleed_height);

						double trim_width = Convert.ToDouble(row["CutSizeW"].ToString());
						double trim_height = Convert.ToDouble(row["CutSizeH"].ToString());
						work.trim_size = new System.Drawing.SizeF((float)trim_width, (float)trim_height);

						work.Platform = row["DataGubun"].ToString();

						if (work.Platform == "0")
							work.file_path = string.Format("{0}IBM\\{1}\\{2}", AppConfiguration.config["ordered_folder"], work.order_date, row["DSFile"].ToString());
						else if (work.Platform == "1")
							work.file_path = string.Format("{0}MAC\\{1}\\{2}", AppConfiguration.config["ordered_folder"], work.order_date, row["DSFile"].ToString());

						work.ColorCode = row["ColorCode"].ToString();
						if (work.ColorCode.Equals("4") == true)
							work.side_count = 1;
						else
							work.side_count = 2;

						work.PaperCode = row["P1Code"].ToString();
						work.PaperQuantity = Convert.ToDouble(row["Qty"].ToString());

						work.Standard = row["Standard"].ToString();

						if (work.category_code == "N13" || work.category_code == "N14" || work.Standard == "1")
							work.magenta_outline = true;
						else
							work.magenta_outline = false;

						String cate1 = work.category_code.Substring(0, 1);
						if (cate1 == "S")
						{
							if ((bleed_width == trim_width) && (bleed_height == trim_height))
								work.magenta_outline = false;
							else
								work.magenta_outline = true;
						}

						work.PeriodAM = row["IsNonstand"].ToString();

						work.ImpositionPosition = row["Digit"].ToString();

						work.CustomerName = row["CustName"].ToString();

						// 2019-12-26 생성된 파일명의 고객이름이 너무 길면 Mac  조판 프로그램인 MoaMoa 에러가 발생 해서 고객명 축사작업 추가
						if (work.CustomerName.Length > 15)
						{
							work.CustomerName = work.CustomerName.Replace(" ", "").Substring(0, 15);
						}
						else
						{
							work.CustomerName = work.CustomerName.Replace(" ", "");
						}



						work.DeliveryCode = row["DCode"].ToString();

						work.ExtraTitle = row["TempTitle"].ToString();
						work.ExtraTitle = work.ExtraTitle.Replace(" ", "");
						if (string.IsNullOrEmpty(work.ExtraTitle) == true)
							work.ExtraTitle = "없음";

						work.SizeCode = row["SizeCode"].ToString();
						work.SubTypeCode = row["SCode"].ToString();

						work.Coating = row["Coating"].ToString();


						if (work_list == null)
							work_list = new List<Work>();
						work_list.Add(work);

					}
				}
				catch
				{
					work_list = null;
				}
			}

			return (work_list == null ? 0 : work_list.Count);
		}


		public static Pair<string, string> SetAcceptProcess(string opi_date, string opi_seq)
		{


			DataTable data_table = new DataTable();
			SqlConnection connection = null;

			// make command
			SqlCommand command = new SqlCommand();
			command.CommandType = CommandType.StoredProcedure;
			command.CommandText = "pdfauto.dbo.ProcAcceptProcess";

			try
			{
				connection = new SqlConnection();
				connection.ConnectionString = m_db_connection;
				connection.Open();

				command.Connection = connection;

				command.Parameters.Add("@OPIDate", SqlDbType.VarChar);
				command.Parameters["@OPIDate"].Value = opi_date;

				command.Parameters.Add("@OPISeq", SqlDbType.VarChar);
				command.Parameters["@OPISeq"].Value = opi_seq;

				SqlDataReader reader = command.ExecuteReader();
				data_table.Load(reader);
			}
			catch
			{

			}
			finally
			{
				if (connection != null)
					connection.Close();
			}

			string log = string.Format("[DB] SetAcceptProcess. query_string: {0}", CommandToQueryString(command));
			//	Logger.Log(log);

			Pair<string, string> pair = null;

			try
			{
				if (data_table != null)
				{
					if (data_table.Rows.Count > 0)
					{
						string accept_message = data_table.Rows[0].ItemArray[0].ToString();
						string accept_result = data_table.Rows[0].ItemArray[1].ToString();

						pair = new Pair<string, string>(accept_message, accept_result);
					}
				}
			}
			catch
			{

			}

			return pair;
		}

		public static Pair<string, string> SetERPProcess(string accept_no, int index, string preview_name)
		{


			DataTable data_table = new DataTable();
			SqlConnection connection = null;

			// make command
			SqlCommand command = new SqlCommand();
			command.CommandType = CommandType.StoredProcedure;
			command.CommandText = "pdfauto.dbo.ProcERProcess";

			try
			{
				connection = new SqlConnection();
				connection.ConnectionString = m_db_connection;
				connection.Open();

				command.Connection = connection;

				command.Parameters.Add("@AcceptNo", SqlDbType.VarChar);
				command.Parameters["@AcceptNo"].Value = accept_no;

				command.Parameters.Add("@AcceptSubNo", SqlDbType.Int);
				command.Parameters["@AcceptSubNo"].Value = index;

				command.Parameters.Add("@PreviewName", SqlDbType.VarChar);
				command.Parameters["@PreviewName"].Value = preview_name;

				SqlDataReader reader = command.ExecuteReader();
				data_table.Load(reader);
			}
			catch
			{

			}
			finally
			{
				if (connection != null)
					connection.Close();
			}

			string log = string.Format("[DB] SetERPProcess. query_string: {0}", CommandToQueryString(command));
			//	Logger.Log(log);

			Pair<string, string> pair = null;

			try
			{
				if (data_table != null)
				{
					if (data_table.Rows.Count > 0)
					{
						string erp_message = data_table.Rows[0].ItemArray[0].ToString();
						string erp_result = data_table.Rows[0].ItemArray[1].ToString();

						pair = new Pair<string, string>(erp_message, erp_result);
					}
				}
			}
			catch
			{

			}

			return pair;
		}

		public static bool SetERPFilePath(string erp_result, string target_file_name, string deposit_folder_path)
		{
			DateTime now = DateTime.Now;

			string query = "INSERT INTO DPrinting..DP_OrderFile(RegDate, Idx, Charge, FileName, FilePath, JumunNo, isDelete, isIncome) " +
								   "VALUES('" + now.ToShortDateString() + "', pdfauto.dbo.UDF_GetOrderFileIDX('" + now.ToShortDateString() + "'), 'AUTO', '" + target_file_name + "', '" + deposit_folder_path + "', '" + erp_result + "', 'N', 'N') ";

			//string log = string.Format("[DB] SetERPFilePath. query_string: {0}", query);
			//Logger.Log(log);

			return UpdateExecute(query);
		}

		public static DataTable  SetERPFilePath_chk(string erp_result)
		{
			DateTime now = DateTime.Now;
			string query = "select jumunNO from DPrinting.dbo.DP_OrderFile where RegDate = '" + now.ToShortDateString() + "' and JumunNo = '" + erp_result +"'";

			//Console.WriteLine(query);

			return QueryExecute(query);

		}



		public static void SetSuccess(int order_common_seqno)
		{
			string[] param = new string[2];
			param[0] = "result=success";
			param[1] = "order_common_seqno=" + order_common_seqno;
			string result1 = request("UpdateAutoResult.php", param);
		}

		public static bool RemoveAccept(int order_common_seqno)
		{
			string[] param = new string[2];
			param[0] = "result=fail";
			param[1] = "order_common_seqno=" + order_common_seqno;
			string result1 = request("UpdateAutoResult.php", param);

			return true;
		}

		public static bool RemoveERP(string erp_result)
		{
			string query1 = "UPDATE DPrinting..DP_JumunDetail " +
								"SET isDELETE = 'Y' " +
								"WHERE JumunNo = '" + erp_result + "' ";

			string log1 = string.Format("[DB] RemoveERP (1). query_string: {0}", query1);
			//	Logger.Log(log1);

			bool result1 = UpdateExecute(query1);

			string query2 = "UPDATE DPrinting..DP_OrderFile " +
					"SET isDELETE = 'Y' " +
					"WHERE JumunNo = '" + erp_result + "' ";

			string log2 = string.Format("[DB] RemoveERP (2). query_string: {0}", query2);
			//	Logger.Log(log2);

			bool result2 = UpdateExecute(query2);

			return (result1 && result2);
		}

		public static void InsertErrorList(string opi_date, string opi_seq, string error_list)
		{


			SqlConnection connection = null;

			// make command
			SqlCommand command = new SqlCommand();
			command.CommandType = CommandType.StoredProcedure;
			command.CommandText = "pdfauto.dbo.ProcInsertError";

			try
			{
				connection = new SqlConnection();
				connection.ConnectionString = m_db_connection;
				connection.Open();

				command.Connection = connection;

				command.Parameters.Add("@OPIDate", SqlDbType.VarChar);
				command.Parameters["@OPIDate"].Value = opi_date;

				command.Parameters.Add("@OPISeq", SqlDbType.VarChar);
				command.Parameters["@OPISeq"].Value = opi_seq;

				command.Parameters.Add("@Contents", SqlDbType.VarChar);
				command.Parameters["@Contents"].Value = error_list;

				command.ExecuteReader();
			}
			catch
			{

			}
			finally
			{
				if (connection != null)
					connection.Close();
			}

			string log = string.Format("[DB] InsertErrorList. query_string: {0}", CommandToQueryString(command));
			//	Logger.Log(log);
		}

		public static bool SetManualAccept(string opi_date, string opi_seq)
		{


			DataTable data_table = new DataTable();
			SqlConnection connection = null;

			// make command
			SqlCommand command = new SqlCommand();
			command.CommandType = CommandType.StoredProcedure;
			command.CommandText = "pdfauto.dbo.ProcWebToAcceptManualAuto";

			try
			{
				connection = new SqlConnection();
				connection.ConnectionString = m_db_connection;
				connection.Open();

				command.Connection = connection;

				command.Parameters.Add("@OPIDate", SqlDbType.VarChar);
				command.Parameters["@OPIDate"].Value = opi_date;

				command.Parameters.Add("@OPISeq", SqlDbType.VarChar);
				command.Parameters["@OPISeq"].Value = opi_seq;

				SqlDataReader reader = command.ExecuteReader();
				data_table.Load(reader);
			}
			catch
			{

			}
			finally
			{
				if (connection != null)
					connection.Close();
			}

			string log = string.Format("[DB] SetManualAccept. query_string: {0}", CommandToQueryString(command));
			//	Logger.Log(log);

			return (data_table == null ? false : true);
		}

		public static Pair<int, int> GetTodayWorkCount(DateTime date_time)
		{
			Pair<int, int> counts = new Pair<int, int>();

			string today = string.Format("{0:0000}-{1:00}-{2:00}", date_time.Year, date_time.Month, date_time.Day);
			string query1 = @"select COUNT(*) from DPrinting..DP_JumunDetail where JDate = '" + today + "' and Charge not in ('최지현', '정지선', '김연화')";
			string query2 = @"select COUNT(*) from DPrinting..DP_JumunDetail where JDate = '" + today + "' and Charge = 'AUTO'";

			string log1 = string.Format("[DB] GetWorkList. query_string: {0}", query1);
			//	Logger.Log(log1);
			string log2 = string.Format("[DB] GetWorkList. query_string: {0}", query2);
			//	Logger.Log(log2);

			try
			{
				DataTable data_table1 = QueryExecute(query1);
				if (data_table1 != null)
				{
					if (data_table1.Rows.Count == 1)
					{
						counts.first = (int)data_table1.Rows[0].ItemArray[0];
					}
				}

				DataTable data_table2 = QueryExecute(query2);
				if (data_table2 != null)
				{
					if (data_table2.Rows.Count == 1)
					{
						counts.second = (int)data_table2.Rows[0].ItemArray[0];
					}
				}
			}
			catch
			{

			}

			return counts;
		}

		public static string GetOrderNo()
		{


			DataTable data_table = new DataTable();
			SqlConnection connection = null;

			// make command
			SqlCommand command = new SqlCommand();
			command.CommandType = CommandType.StoredProcedure;
			command.CommandText = "DPrinting.dbo.USP_GetJumunNo";

			try
			{
				connection = new SqlConnection();
				connection.ConnectionString = m_db_connection;
				connection.Open();

				command.Connection = connection;

				SqlDataReader reader = command.ExecuteReader();
				data_table.Load(reader);
			}
			catch
			{

			}
			finally
			{
				if (connection != null)
					connection.Close();
			}

			string log = string.Format("[DB] USP_GetJumunNo. query_string: {0}", CommandToQueryString(command));
			//	Logger.Log(log);

			string order_no = string.Empty;
			if (data_table != null)
			{
				if (data_table.Rows.Count > 0)
				{
					order_no = data_table.Rows[0].ItemArray[0].ToString();
				}
			}

			return order_no;
		}

		public static string GetOrderTitle(string order_no)
		{


			string query = @"SELECT JumunTitle FROM DPrinting..DP_JumunDetail WHERE JumunNo = '" + order_no + "'";

			string log = string.Format("[DB] GetOrderTitle. query_string: {0}", query);
			//	Logger.Log(log);

			string order_title = string.Empty;

			DataTable data_table = QueryExecute(query);
			if (data_table != null)
			{
				if (data_table.Rows.Count > 0)
				{
					order_title = data_table.Rows[0].ItemArray[0].ToString();
				}
			}

			return order_title;
		}

		public static string GetPaperCode(string order_no)
		{


			string query = @"SELECT PaperCode FROM DPrinting..DP_JumunDetail WHERE JumunNo = '" + order_no + "'";

			// string log = string.Format("[DB] GetPaperCode. query_string: {0}", query);
			//	Logger.Log(log);

			string paper_code = string.Empty;

			DataTable data_table = QueryExecute(query);
			if (data_table != null)
			{
				if (data_table.Rows.Count > 0)
				{
					paper_code = data_table.Rows[0].ItemArray[0].ToString();
				}
			}

			return paper_code;
		}

		public static string GetMemo(string opi_date, string opi_seq)
		{


			string query = @"SELECT Memo FROM GoodPrinting..WEB_OrderPInfo WHERE OPI_Date = '" + opi_date + "' and OPI_Seq = '" + opi_seq + "'";

			string log = string.Format("[DB] GetMemo. query_string: {0}", query);
			//	Logger.Log(log);

			string memo = string.Empty;

			DataTable data_table = QueryExecute(query);
			if (data_table != null)
			{
				if (data_table.Rows.Count > 0)
				{
					memo = data_table.Rows[0].ItemArray[0].ToString();
				}
			}

			return memo;
		}

		public static bool InsertNameCardAPCode(string order_no, string apcode, double paper_quantity, double price)
		{
			string query = "INSERT INTO DP_JumunAPInfo(JumunNo, Seq, APCode, JumunQty, Price) " +
								"VALUES('" + order_no + "', 4, '" + apcode + "'," + paper_quantity.ToString() + ", " + price.ToString() + ")";

			string log = string.Format("[DB] InsertNameCardAPCode. query_string: {0}", query);
			//	Logger.Log(log);

			return UpdateExecute(query);
		}

		public static bool DeleteNameCardAPCode(string order_no)
		{
			string query = "DELETE FROM DPrinting..DP_JumunAPInfo WHERE JumunNo = '" + order_no + "'";

			string log = string.Format("[DB] DeleteNameCardAPCode. query_string: {0}", query);
			//	Logger.Log(log);

			return UpdateExecute(query);
		}

		public static bool InsertStickerAPCode(string order_no, double paper_quantity)
		{
			string query = "INSERT INTO DP_JumunAPInfo(JumunNo, Seq, APCode, JumunQty, Price) " +
								"VALUES('" + order_no + "', 0, '35'," + paper_quantity.ToString() + ", 0)";

			string log = string.Format("[DB] InsertStickerAPCode. query_string: {0}", query);
			//	Logger.Log(log);

			return UpdateExecute(query);
		}

		public static bool DeleteStickerAPCode(string order_no)
		{
			string query = "DELETE FROM DPrinting..DP_JumunAPInfo WHERE JumunNo = '" + order_no + "'";

			string log = string.Format("[DB] DeleteStickerAPCode. query_string: {0}", query);
			//	Logger.Log(log);

			return UpdateExecute(query);
		}

		public static string GetDeliveryMode(string opi_date, string opi_seq)
		{


			string query = @"SELECT Deli_Mode FROM GoodPrinting..web_orderpinfoDetail WHERE OPI_Date = '" + opi_date + "' and OPI_Seq = '" + opi_seq + "'";

			string log = string.Format("[DB] GetDeliveryMode. query_string: {0}", query);
			//	Logger.Log(log);

			string delivery_mode = string.Empty;

			DataTable data_table = QueryExecute(query);
			if (data_table != null)
			{
				if (data_table.Rows.Count > 0)
				{
					delivery_mode = data_table.Rows[0].ItemArray[0].ToString();
				}
			}

			return delivery_mode;
		}

		public static int GetAcceptCustID(string customer_id)
		{


			string query = @"SELECT MasterCust FROM DPrinting..DP_CUSTOMER WHERE CustID = '" + customer_id + "'";

			string log = string.Format("[DB] GetAcceptCustID. query_string: {0}", query);
			//	Logger.Log(log);

			int cust_id = 0;

			DataTable data_table = QueryExecute(query);
			if (data_table != null)
			{
				if (data_table.Rows.Count > 0)
				{
					string master_cust = data_table.Rows[0].ItemArray[0].ToString();
					switch (master_cust)
					{
						case "4110": cust_id = 2; break;
						case "4811": cust_id = 0; break;
						case "4812": cust_id = 1; break;
						case "17624": cust_id = 6; break;
						case "22978": cust_id = 6; break;
						case "9999": cust_id = 7; break;
					}
				}
			}

			return cust_id;
		}

		public static Dictionary<string, double> GetFinishList(string opi_date, string opi_seq)
		{
			string query = @"SELECT AGroup_1, AGroup_2, Price FROM GoodPrinting..WEB_OrderAfterInfo WHERE OPI_Date = '" + opi_date + "' and OPI_Seq = '" + opi_seq + "'";
			string log = string.Format("[DB] GetFinishList. query_string: {0}", query);
			//	Logger.Log(log);

			Dictionary<string, double> finish_list = null;

			DataTable data_table = QueryExecute(query);
			if (data_table != null)
			{
				foreach (DataRow row in data_table.Rows)
				{
					string finish = string.Format("{0}{1}", row["AGroup_1"].ToString(), row["AGroup_2"].ToString());

					if (finish_list == null)
						finish_list = new Dictionary<string, double>();
					if (finish_list.ContainsKey(finish) == false)
						finish_list.Add(finish, Convert.ToDouble(row["Price"].ToString()));
				}
			}

			return finish_list;
		}

		public static bool RequestQCCheck(string opi_date, string opi_seq, string message)
		{

			string query1 = @"SELECT QCCheck FROM pdfauto..TbDPAutoErrorList WHERE OPIDate = '" + opi_date + "' AND OPISeq = '" + opi_seq + "'";

			//string log1 = string.Format("[DB] RequestQCCheck. query_string: {0}", query1);
			//	Logger.Log(log1);

			bool result = false;
			DataTable data_table = QueryExecute(query1);
			if (data_table != null)
			{
				if (data_table.Rows.Count > 0)
				{
					string query2 = @"UPDATE pdfauto..TbDPAutoErrorList SET QCCheck = '" + message + "' " +
														"WHERE OPIDate = '" + opi_date + "' AND OPISeq = '" + opi_seq + "'";

					string log2 = string.Format("[DB] RequestQCCheck. query_string: {0}", query2);
					//		Logger.Log(log2);

					result = UpdateExecute(query2);
				}
				else
				{
					string query2 = @"INSERT INTO pdfauto..TbDPAutoErrorList(OPIDate, OPISeq, Status, Contents, QCCheck)
														VALUES('" + opi_date + "', '" + opi_seq + "', 'S', '', '" + message + "')";

					string log2 = string.Format("[DB] RequestQCCheck. query_string: {0}", query2);
					//		Logger.Log(log2);

					result = UpdateExecute(query2);
				}
			}

			return result;
		}

		public static DataTable QueryExecute(string query)
		{
			DataTable data_table = new DataTable();
			SqlConnection connection = null;

			try
			{
				connection = new SqlConnection();
				connection.ConnectionString = m_db_connection;
				connection.Open();

				SqlCommand command = new SqlCommand(query, connection);
				SqlDataAdapter adapter = new SqlDataAdapter(command);
				adapter.Fill(data_table);
			}
			catch
			{
			}
			finally
			{
				if (connection != null)
					connection.Close();
			}

			return data_table;
		}

		public static bool UpdateExecute(string query)
		{
			bool result = false;
			SqlConnection connection = null;

			try
			{
				connection = new SqlConnection();
				connection.ConnectionString = m_db_connection;
				connection.Open();

				SqlCommand command = new SqlCommand(query, connection);
				SqlDataAdapter adapter = new SqlDataAdapter(command);
				command.ExecuteReader();

				result = true;
			}
			catch
			{
			}
			finally
			{
				if (connection != null)
					connection.Close();
			}

			return result;
		}

		public static string CommandToQueryString(SqlCommand command)
		{
			string query_string = "CALL " + command.CommandText + "(";

			try
			{
				if (command.Parameters.Count > 0)
				{
					for (int i = 0; i < command.Parameters.Count; i++)
					{
						query_string = String.Concat(query_string, command.Parameters[i].Value.ToString(), ", ");
					}

					query_string = query_string.Substring(0, query_string.Length - 2);
					query_string = String.Concat(query_string, ")");
				}
				else
				{
					query_string = String.Concat(query_string, ")");
				}
			}
			catch
			{

			}

			return query_string;
		}

		public static string request(string path, string[] strs)
		{

			string strUri = "http://yesprinting.co.kr/moamoa/process/" + path;
			// POST, GET 보낼 데이터 입력

			StringBuilder dataParams = new StringBuilder();
			if (strs != null)
			{
				int i = 0;
				foreach (string str in strs)
				{
					if (dataParams.Length == 0)
					{
						dataParams.Append(str);
					}
					else
					{
						dataParams.Append("&" + str);
					}
					i++;
				}
			}

			// 요청 String -> 요청 Byte 변환
			byte[] byteDataParams = UTF8Encoding.UTF8.GetBytes(dataParams.ToString());

			/* GET */
			// GET 방식은 Uri 뒤에 보낼 데이터를 입력하시면 됩니다.

			HttpWebRequest request = (HttpWebRequest)WebRequest.Create(strUri + "?" + dataParams);
			request.Method = "GET";

			HttpWebResponse response = (HttpWebResponse)request.GetResponse();
			Stream stReadData = response.GetResponseStream();
			StreamReader srReadData = new StreamReader(stReadData, Encoding.UTF8);

			string strResult = srReadData.ReadToEnd();
			return strResult;
		}
	}


}
