﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoCC_Main
{
    static public class PathHelper
    {
        //public const string ServerAddress = "http://192.168.20.60:8080";

        //페퍼
        //public const string ServerAddress = "http://172.30.1.22:7777";

        //굿프린팅
        //public const string ServerAddress = "http://172.16.33.90:7777";

        //굿프린팅4
        //public const string ServerAddress = "http://172.16.33.149:7777";
        public const string ServerAddress = "http://211.110.168.84:7777";

        public const string RootPath = @"C:\";
    }
}
